package com.softura.beneficiarysubscriberapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeneficiarysubscriberapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
