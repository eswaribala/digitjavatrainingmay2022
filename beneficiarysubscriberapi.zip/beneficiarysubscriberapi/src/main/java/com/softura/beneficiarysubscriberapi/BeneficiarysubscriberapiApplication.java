package com.softura.beneficiarysubscriberapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeneficiarysubscriberapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeneficiarysubscriberapiApplication.class, args);
	}

}
