package com.softura.healthcareapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareappApplicationTests {

	@Test
	void contextLoads() {
	}

}
