package com.softura.beneficiaryreqapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeneficiaryreqapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
