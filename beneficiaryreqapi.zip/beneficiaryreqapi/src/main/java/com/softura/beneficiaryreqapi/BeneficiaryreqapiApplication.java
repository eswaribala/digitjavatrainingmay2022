package com.softura.beneficiaryreqapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeneficiaryreqapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeneficiaryreqapiApplication.class, args);
	}

}
