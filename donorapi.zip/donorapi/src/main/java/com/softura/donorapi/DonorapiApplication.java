package com.softura.donorapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonorapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonorapiApplication.class, args);
	}

}
