package com.softura.healthcareapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
