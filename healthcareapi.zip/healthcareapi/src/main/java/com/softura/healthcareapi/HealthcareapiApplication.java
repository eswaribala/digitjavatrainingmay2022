package com.softura.healthcareapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthcareapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcareapiApplication.class, args);
	}

}
